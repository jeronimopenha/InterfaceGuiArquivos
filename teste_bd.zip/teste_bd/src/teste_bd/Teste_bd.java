
package teste_bd;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;


public class Teste_bd {

    public static void main(String[] args) {
        
        //inserirDadoNoBD("Abacate");
        excluirDadoNoBD(2);
        alterarDadoNoBD(3, "Banana");
        imprimirBD();
    }
    
    public static void alterarDadoNoBD(int id, String descricao){
        Connection con = connection.ConnectionFactory.getConnection();
        
        try {
            PreparedStatement stm = con.prepareStatement("UPDATE `produto` "
                    + "SET `Descricao` = ? WHERE produtoid = ?");
            stm.setString(1, descricao);
            stm.setInt(2, id);
            stm.execute();
            connection.ConnectionFactory.closeConnection(con, stm);
            
        } catch (SQLException ex) {
            Logger.getLogger(Teste_bd.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            connection.ConnectionFactory.closeConnection(con);
        }
    }
    
    public static void excluirDadoNoBD(int id){
        Connection con = connection.ConnectionFactory.getConnection();
        
        try {
            PreparedStatement stm = con.prepareStatement("delete from produto "
                    + "where produtoid = ?");
            stm.setInt(1, id);
            stm.execute();
            connection.ConnectionFactory.closeConnection(con, stm);
            
        } catch (SQLException ex) {
            Logger.getLogger(Teste_bd.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            connection.ConnectionFactory.closeConnection(con);
        }
    }
    
    public static void inserirDadoNoBD(String dado){
        Connection con = connection.ConnectionFactory.getConnection();
        
        try {
            PreparedStatement stm = con.prepareStatement("insert into produto "
                    + "(descricao) values (?)");
            stm.setString(1, dado);
            stm.execute();
            connection.ConnectionFactory.closeConnection(con, stm);
            
        } catch (SQLException ex) {
            Logger.getLogger(Teste_bd.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            connection.ConnectionFactory.closeConnection(con);
        }
    }
    
    public static void imprimirBD(){
        Connection con = connection.ConnectionFactory.getConnection();
        
        try {
            PreparedStatement stm = con.prepareStatement("Select * from produto"
                    + " order by descricao asc");
            ResultSet rs = stm.executeQuery();
            
            while(rs.next()){
                System.out.println(rs.getString("descricao"));
            }
            connection.ConnectionFactory.closeConnection(con, stm, rs);
            
        } catch (SQLException ex) {
            Logger.getLogger(Teste_bd.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            connection.ConnectionFactory.closeConnection(con);
        }
    }
    
}
